/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 
/**
 *
 * @author Kenji
 */
public class RegUser {
    public String ID;
    public String FirstName;
    public String LastName;
    public String Address;
    public String Phone;
    public String Email;
    public String City;
    public String State;
    public String Zip;
    public String Occupation;
    public String DateOfBirth;  
}
