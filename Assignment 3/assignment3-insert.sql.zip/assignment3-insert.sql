use ASS3;

insert into customer (cus_code, cus_lname, cus_fname, cus_initial, cus_areacode, cus_phone) values 
  (10010, 'Ramas', 'Alfred', 'A', 615, 8442573),
  (10011, 'Dunne', 'Leona', 'K', 713, 8941238),
  (10012, 'Smith', 'Kathy', 'W', 615, 8942285),
  (10013, 'Olowski', 'Paul', 'F', 615, 2221672),
  (10014, 'Orlando', 'Myron', NULL, 615, 2971228);

insert into invoice (inv_number, cus_code, inv_date) values 
  (1001, 10011, '2008-08-03'),
  (1002, 10014, '2008-08-04'),
  (1003, 10012, '2008-03-20'),
  (1004, 10011, '2008-09-23');

insert into line (inv_number, prod_code, line_units) values 
  (1001, 12321, 1),
  (1001, 65781, 3),
  (1002, 34256, 6),
  (1003, 12321, 5),
  (1002, 12333, 6);

insert into product (prod_code, prod_desc, prod_price, prod_quant, vend_code) values 
  (12321, 'hammer', 189, 20, 232),
  (65781, 'chain', 12, 45, 235),
  (34256, 'tape', 35, 60, 235),
  (12333, 'hanger', 200, 10, 232);

insert into vendor (vend_code, vend_name, vend_contact, vend_areacode, vend_phone) values 
  (232, 'Bryson', 'Smith', 615, 2233234),
  (235, 'SuperLoo', 'Anderson', 615, 2158995);