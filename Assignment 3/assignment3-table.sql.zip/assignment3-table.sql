use ASS3;
create table customer (
    cus_code integer primary key,
    cus_lname varchar(20),
    cus_fname varchar(20),
    cus_initial char,
    cus_areacode integer,
    cus_phone integer
);
create table invoice (
    inv_number integer primary key,
    cus_code integer,
    inv_date date,
    foreign key (cus_code) references customer(cus_code)
);
create table line (
    inv_number integer,
    prod_code integer,
    line_units integer,
    foreign key (inv_number) references invoice(inv_number) on delete cascade,
    foreign key (prod_code) references product(prod_code) on delete cascade
);
create table product (
    prod_code integer primary key,
    prod_desc varchar(50),
    prod_price integer,
    prod_quant integer,
    vend_code integer,
    foreign key (vend_code) references vendor(vend_code) on delete set null
);
create table vendor (
    vend_code integer primary key,
    vend_name varchar(30),
    vend_contact varchar(30),
    vend_areacode integer,
    vend_phone integer
);
