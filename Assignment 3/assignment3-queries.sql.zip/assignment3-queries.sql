use ASS3;
-- List the invoice number and invoice date for all invoices of customer number 10011  
select inv_number, inv_date 
from invoice 
where cus_code = 10011;

--  List the product number and product quantity for products in invoice number 1001
select product.prod_code, product.prod_quant, line_units
from line 
join product on line.prod_code = product.prod_code
where line.inv_number = 1001;

-- List all product description and product price supplied by vendor whose vendor contact name is Smith
select prod_desc, prod_price 
from product 
inner join vendor on product.vend_code = vendor.vend_code
where vend_contact = 'Smith'; 

-- Produce a list of product description, vendor name, and vendor phone for all products with price less than 50.
select prod_desc, vendor.vend_name, vendor.vend_phone
from product
inner join vendor
ON product.vend_code = vendor.vend_code
WHERE product.prod_price < 50;


-- For each product bought by a customer, list product description and customer’s first name and last name.
select prod_desc, customer.cus_lname, customer.cus_fname
from product
join line on product.prod_code = line.prod_code
join invoice on line.inv_number = invoice.inv_number
join customer on invoice.cus_code = customer.cus_code
ORDER BY customer.cus_lname, customer.cus_fname;


-- How many vendors supplied products that are cheaper than 50?
select count(vendor.vend_code) from product
join vendor on product.vend_code = vendor.vend_code
where prod_price < 50;

-- For each vendor, find the cheapest product
select vendor.vend_name, prod_desc, prod_price
from product
join vendor on product.vend_code = vendor.vend_code
where prod_price = (
  select min(prod_price)
  from product
  where vend_code = vendor.vend_code
);

 
 -- For each invoice, find the total price.
select invoice.inv_number, sum(line_units * prod_price) as total_price
from invoice
join line on invoice.inv_number = line.inv_number
join product on line.prod_code = product.prod_code
group by inv_number;


 -- Find how many products are there in each invoice
select invoice.inv_number, count(*) as num_products
from invoice
join line on invoice.inv_number = line.inv_number
join product on line.prod_code = product.prod_code
group by invoice.inv_number;


 -- Find how many invoices are made by each customer.
select cus_code, count(*) as number_invoices
from invoice
group by cus_code;

 -- Find how many products are bought by each customer 
select customer.cus_code, count(*) as num_products
from customer
join invoice on customer.cus_code = invoice.cus_code
join line on invoice.inv_number = line.inv_number
group by cus_code;


 -- Find vendor code, vendor contact and the number of product supplied by each vendor  not worked
select vendor.vend_code, vendor.vend_contact, count(*) as num_products
from vendor
inner join product on vendor.vend_code = product.vend_code
group by vend_code, vend_contact; 

